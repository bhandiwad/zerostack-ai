import React, { useState, useEffect } from 'react';
import './App.css';
import ClusterCreation from './ClusterCreation.jsx';

// Authentication Context
const AuthContext = React.createContext();

// API Configuration
const API_BASE_URL = 'http://localhost:5002/api';

// API Helper Functions
const apiCall = async (endpoint, options = {}) => {
  const token = localStorage.getItem('jwt_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` }),
    ...options.headers
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers
    });

    if (response.status === 401) {
      localStorage.removeItem('jwt_token');
      localStorage.removeItem('user_data');
      window.location.reload();
      return null;
    }

    const data = await response.json();
    
    // For non-2xx responses, still return the parsed JSON so error handling works
    if (!response.ok && data) {
      return data;
    }
    
    return data;
  } catch (error) {
    console.error('API call failed:', error);
    return { success: false, error: error.message };
  }
};

// Login Component
const LoginForm = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    email: 'admin@sifytechnologies.com',
    password: 'SifyAdmin123!'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const result = await apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify(formData)
    });

    if (result && result.success) {
      localStorage.setItem('jwt_token', result.data.token);
      localStorage.setItem('user_data', JSON.stringify(result.data.user));
      localStorage.setItem('organization_data', JSON.stringify(result.data.organization));
      onLogin(result.data);
    } else {
      setError(result?.error || 'Login failed');
    }

    setLoading(false);
  };

  const handleDemoLogin = (email, password) => {
    setFormData({ email, password });
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <h1>🏢 Sify Cluster-API Console</h1>
          <p>Multi-Tenant Kubernetes Management Platform</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label>Email Address</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              required
              placeholder="Enter your email"
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              required
              placeholder="Enter your password"
            />
          </div>

          {error && <div className="error-message">{error}</div>}

          <button type="submit" disabled={loading} className="login-button">
            {loading ? '🔄 Signing In...' : '🔐 Sign In'}
          </button>
        </form>

        <div className="demo-accounts">
          <h3>Demo Accounts</h3>
          <div className="demo-buttons">
            <button 
              onClick={() => handleDemoLogin('admin@sifytechnologies.com', 'SifyAdmin123!')}
              className="demo-button sify"
            >
              🏢 Sify Technologies (Enterprise)
            </button>
            <button 
              onClick={() => handleDemoLogin('admin@example.com', 'DemoAdmin123!')}
              className="demo-button demo"
            >
              🏢 Demo Company (Professional)
            </button>
            <button 
              onClick={() => handleDemoLogin('founder@techstartup.com', 'StartupFounder123!')}
              className="demo-button startup"
            >
              🏢 Tech Startup (Free)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Header Component
const Header = ({ user, organization, onLogout }) => {
  return (
    <header className="app-header">
      <div className="header-left">
        <h1>🏢 Cluster-API Console</h1>
        <span className="powered-by">Powered by Sify</span>
      </div>
      <div className="header-right">
        <div className="organization-info">
          <div className="org-name">{organization?.name}</div>
          <div className="org-tier">{organization?.subscription_tier}</div>
        </div>
        <div className="user-info">
          <div className="user-name">{user?.full_name}</div>
          <div className="user-role">{user?.role?.replace('_', ' ')}</div>
        </div>
        <button onClick={onLogout} className="logout-button">
          🚪 Logout
        </button>
      </div>
    </header>
  );
};

// Dashboard Component
const Dashboard = ({ organization }) => {
  const [dashboardData, setDashboardData] = useState({
    clusters: [],
    totalClusters: 0,
    activeNodes: 0,
    monthlyCost: 0,
    loading: true
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    const result = await apiCall('/mt/clusters');
    if (result && result.success) {
      const clusters = result.data;
      const totalNodes = clusters.reduce((sum, cluster) => sum + cluster.node_count, 0);
      const totalCost = clusters.reduce((sum, cluster) => sum + cluster.monthly_cost, 0);

      setDashboardData({
        clusters,
        totalClusters: clusters.length,
        activeNodes: totalNodes,
        monthlyCost: totalCost,
        loading: false
      });
    } else {
      setDashboardData(prev => ({ ...prev, loading: false }));
    }
  };

  const getProviderDistribution = () => {
    const providers = {};
    dashboardData.clusters.forEach(cluster => {
      providers[cluster.provider] = (providers[cluster.provider] || 0) + 1;
    });
    return providers;
  };

  if (dashboardData.loading) {
    return <div className="loading">🔄 Loading dashboard...</div>;
  }

  const providerDistribution = getProviderDistribution();

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h2>📊 Organization Dashboard</h2>
        <div className="org-limits">
          <span>Clusters: {dashboardData.totalClusters}/{organization?.max_clusters}</span>
          <span>Subscription: {organization?.subscription_tier}</span>
        </div>
      </div>

      <div className="dashboard-stats">
        <div className="stat-card">
          <h3>Total Clusters</h3>
          <div className="stat-value">{dashboardData.totalClusters}</div>
          <div className="stat-change">📈 Active</div>
        </div>

        <div className="stat-card">
          <h3>Active Nodes</h3>
          <div className="stat-value">{dashboardData.activeNodes}</div>
          <div className="stat-change">⚡ Running</div>
        </div>

        <div className="stat-card">
          <h3>Cloud Providers</h3>
          <div className="stat-value">{Object.keys(providerDistribution).length}</div>
          <div className="stat-change">☁️ Multi-cloud</div>
        </div>

        <div className="stat-card">
          <h3>Monthly Cost</h3>
          <div className="stat-value">${dashboardData.monthlyCost.toFixed(0)}</div>
          <div className="stat-change">💰 Estimated</div>
        </div>
      </div>

      <div className="dashboard-content">
        <div className="provider-distribution">
          <h3>Provider Distribution</h3>
          <div className="provider-list">
            {Object.entries(providerDistribution).map(([provider, count]) => (
              <div key={provider} className="provider-item">
                <span className="provider-name">{provider.toUpperCase()}</span>
                <span className="provider-count">{count} clusters</span>
              </div>
            ))}
          </div>
        </div>

        <div className="recent-clusters">
          <h3>Recent Clusters</h3>
          <div className="cluster-list">
            {dashboardData.clusters.slice(0, 5).map(cluster => (
              <div key={cluster.id} className="cluster-item">
                <div className="cluster-info">
                  <div className="cluster-name">{cluster.name}</div>
                  <div className="cluster-details">
                    {cluster.provider} • {cluster.region} • {cluster.node_count} nodes
                  </div>
                </div>
                <div className="cluster-status">
                  <span className={`status ${cluster.status}`}>{cluster.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Cluster Management Component
const ClusterManagement = () => {
  const [clusters, setClusters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCluster, setSelectedCluster] = useState(null);
  const [showScaleDialog, setShowScaleDialog] = useState(false);
  const [scaleNodeCount, setScaleNodeCount] = useState(1);

  useEffect(() => {
    loadClusters();
  }, []);

  const loadClusters = async () => {
    const result = await apiCall('/mt/clusters');
    if (result && result.success) {
      setClusters(result.data);
    }
    setLoading(false);
  };

  const handleScaleCluster = async () => {
    if (!selectedCluster) return;

    const result = await apiCall(`/mt/clusters/${selectedCluster.id}/scale`, {
      method: 'POST',
      body: JSON.stringify({ nodeCount: scaleNodeCount })
    });

    if (result && result.success) {
      setShowScaleDialog(false);
      loadClusters(); // Refresh the list
      alert(`Cluster scaling initiated: ${selectedCluster.name} → ${scaleNodeCount} nodes`);
    } else {
      alert(`Scaling failed: ${result?.error || 'Unknown error'}`);
    }
  };

  const handleDeleteCluster = async (cluster) => {
    if (!confirm(`Are you sure you want to delete cluster "${cluster.name}"?`)) return;

    const result = await apiCall(`/mt/clusters/${cluster.id}`, {
      method: 'DELETE'
    });

    if (result && result.success) {
      loadClusters(); // Refresh the list
      alert(`Cluster deletion initiated: ${cluster.name}`);
    } else {
      alert(`Deletion failed: ${result?.error || 'Unknown error'}`);
    }
  };

  if (loading) {
    return <div className="loading">🔄 Loading clusters...</div>;
  }

  return (
    <div className="cluster-management">
      <div className="page-header">
        <h2>⚙️ Cluster Management</h2>
        <p>Manage your Kubernetes clusters across multiple cloud providers</p>
      </div>

      {clusters.length === 0 ? (
        <div className="empty-state">
          <h3>No clusters found</h3>
          <p>Create your first cluster to get started</p>
        </div>
      ) : (
        <div className="clusters-grid">
          {clusters.map(cluster => (
            <div key={cluster.id} className="cluster-card">
              <div className="cluster-header">
                <h3>{cluster.name}</h3>
                <span className={`status ${cluster.status}`}>{cluster.status}</span>
              </div>

              <div className="cluster-details">
                <div className="detail-row">
                  <span>Provider:</span>
                  <span>{cluster.provider.toUpperCase()}</span>
                </div>
                <div className="detail-row">
                  <span>Region:</span>
                  <span>{cluster.region}</span>
                </div>
                <div className="detail-row">
                  <span>Version:</span>
                  <span>{cluster.version}</span>
                </div>
                <div className="detail-row">
                  <span>Nodes:</span>
                  <span>{cluster.node_count}</span>
                </div>
                <div className="detail-row">
                  <span>Cost:</span>
                  <span>${cluster.monthly_cost}/month</span>
                </div>
                {cluster.gpu_count > 0 && (
                  <div className="detail-row">
                    <span>GPUs:</span>
                    <span>{cluster.gpu_count}x {cluster.gpu_type}</span>
                  </div>
                )}
              </div>

              <div className="cluster-actions">
                <button 
                  onClick={() => {
                    setSelectedCluster(cluster);
                    setScaleNodeCount(cluster.node_count);
                    setShowScaleDialog(true);
                  }}
                  className="action-button scale"
                >
                  📈 Scale
                </button>
                <button 
                  onClick={() => handleDeleteCluster(cluster)}
                  className="action-button delete"
                >
                  🗑️ Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Scale Dialog */}
      {showScaleDialog && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Scale Cluster: {selectedCluster?.name}</h3>
            <div className="form-group">
              <label>Node Count:</label>
              <input
                type="number"
                min="1"
                max="20"
                value={scaleNodeCount}
                onChange={(e) => setScaleNodeCount(parseInt(e.target.value))}
              />
            </div>
            <div className="modal-actions">
              <button onClick={() => setShowScaleDialog(false)} className="cancel-button">
                Cancel
              </button>
              <button onClick={handleScaleCluster} className="confirm-button">
                Scale Cluster
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Cloud Account Manager Component
const CloudAccountManager = () => {
  const [accounts, setAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    provider: 'aws',
    credentials: {
      aws_access_key_id: '',
      aws_secret_access_key: '',
      region: 'us-east-1'
    }
  });

  useEffect(() => {
    loadCloudAccounts();
  }, []);

  const loadCloudAccounts = async () => {
    const result = await apiCall('/cloud-accounts');
    if (result && result.success) {
      setAccounts(result.data || []);
    }
    setLoading(false);
  };

  const handleProviderChange = (provider) => {
    let defaultCredentials = {};
    switch (provider) {
      case 'aws':
        defaultCredentials = {
          aws_access_key_id: '',
          aws_secret_access_key: '',
          region: 'us-east-1'
        };
        break;
      case 'gcp':
        defaultCredentials = {
          project_id: '',
          service_account_key: '',
          region: 'us-central1'
        };
        break;
      case 'azure':
        defaultCredentials = {
          subscription_id: '',
          client_id: '',
          client_secret: '',
          tenant_id: '',
          region: 'East US'
        };
        break;
    }
    setFormData({ ...formData, provider, credentials: defaultCredentials });
  };

  const handleCredentialChange = (key, value) => {
    setFormData({
      ...formData,
      credentials: { ...formData.credentials, [key]: value }
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await apiCall('/cloud-accounts', {
      method: 'POST',
      body: JSON.stringify(formData)
    });

    if (result && result.success) {
      alert(`✅ Cloud account "${formData.name}" added successfully!`);
      setShowAddForm(false);
      setFormData({
        name: '',
        provider: 'aws',
        credentials: {
          aws_access_key_id: '',
          aws_secret_access_key: '',
          region: 'us-east-1'
        }
      });
      loadCloudAccounts();
    } else {
      alert(`❌ Failed to add cloud account: ${result?.error || 'Unknown error'}`);
    }

    setLoading(false);
  };

  const deleteAccount = async (accountId) => {
    if (!confirm('Are you sure you want to delete this cloud account?')) return;

    const result = await apiCall(`/cloud-accounts/${accountId}`, {
      method: 'DELETE'
    });

    if (result && result.success) {
      alert('✅ Cloud account deleted successfully!');
      loadCloudAccounts();
    } else {
      alert(`❌ Failed to delete cloud account: ${result?.error || 'Unknown error'}`);
    }
  };

  const renderCredentialFields = () => {
    switch (formData.provider) {
      case 'aws':
        return (
          <>
            <div className="form-group">
              <label>AWS Access Key ID *</label>
              <input
                type="text"
                value={formData.credentials.aws_access_key_id}
                onChange={(e) => handleCredentialChange('aws_access_key_id', e.target.value)}
                placeholder="AKIA..."
                required
              />
            </div>
            <div className="form-group">
              <label>AWS Secret Access Key *</label>
              <input
                type="password"
                value={formData.credentials.aws_secret_access_key}
                onChange={(e) => handleCredentialChange('aws_secret_access_key', e.target.value)}
                placeholder="Enter secret access key"
                required
              />
            </div>
            <div className="form-group">
              <label>Default Region</label>
              <select
                value={formData.credentials.region}
                onChange={(e) => handleCredentialChange('region', e.target.value)}
              >
                <option value="us-east-1">US East (N. Virginia)</option>
                <option value="us-west-2">US West (Oregon)</option>
                <option value="eu-west-1">Europe (Ireland)</option>
                <option value="ap-south-1">Asia Pacific (Mumbai)</option>
                <option value="ap-southeast-1">Asia Pacific (Singapore)</option>
              </select>
            </div>
          </>
        );
      case 'gcp':
        return (
          <>
            <div className="form-group">
              <label>Project ID *</label>
              <input
                type="text"
                value={formData.credentials.project_id}
                onChange={(e) => handleCredentialChange('project_id', e.target.value)}
                placeholder="my-gcp-project"
                required
              />
            </div>
            <div className="form-group">
              <label>Service Account Key (JSON) *</label>
              <textarea
                value={formData.credentials.service_account_key}
                onChange={(e) => handleCredentialChange('service_account_key', e.target.value)}
                placeholder="Paste your service account JSON key here"
                rows="4"
                required
              />
            </div>
            <div className="form-group">
              <label>Default Region</label>
              <select
                value={formData.credentials.region}
                onChange={(e) => handleCredentialChange('region', e.target.value)}
              >
                <option value="us-central1">US Central 1</option>
                <option value="us-east1">US East 1</option>
                <option value="europe-west1">Europe West 1</option>
                <option value="asia-south1">Asia South 1</option>
                <option value="asia-southeast1">Asia Southeast 1</option>
              </select>
            </div>
          </>
        );
      case 'azure':
        return (
          <>
            <div className="form-group">
              <label>Subscription ID *</label>
              <input
                type="text"
                value={formData.credentials.subscription_id}
                onChange={(e) => handleCredentialChange('subscription_id', e.target.value)}
                placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                required
              />
            </div>
            <div className="form-group">
              <label>Client ID *</label>
              <input
                type="text"
                value={formData.credentials.client_id}
                onChange={(e) => handleCredentialChange('client_id', e.target.value)}
                placeholder="Application (client) ID"
                required
              />
            </div>
            <div className="form-group">
              <label>Client Secret *</label>
              <input
                type="password"
                value={formData.credentials.client_secret}
                onChange={(e) => handleCredentialChange('client_secret', e.target.value)}
                placeholder="Enter client secret"
                required
              />
            </div>
            <div className="form-group">
              <label>Tenant ID *</label>
              <input
                type="text"
                value={formData.credentials.tenant_id}
                onChange={(e) => handleCredentialChange('tenant_id', e.target.value)}
                placeholder="Directory (tenant) ID"
                required
              />
            </div>
            <div className="form-group">
              <label>Default Region</label>
              <select
                value={formData.credentials.region}
                onChange={(e) => handleCredentialChange('region', e.target.value)}
              >
                <option value="East US">East US</option>
                <option value="West US 2">West US 2</option>
                <option value="West Europe">West Europe</option>
                <option value="Southeast Asia">Southeast Asia</option>
                <option value="Central India">Central India</option>
              </select>
            </div>
          </>
        );
    }
  };

  if (loading && accounts.length === 0) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading cloud accounts...</p>
      </div>
    );
  }

  return (
    <div className="cloud-accounts-container">
      <div className="page-header">
        <h2>☁️ Cloud Account Management</h2>
        <p>Manage your cloud provider credentials for cluster provisioning</p>
        <button 
          className="btn-primary"
          onClick={() => setShowAddForm(!showAddForm)}
        >
          {showAddForm ? '❌ Cancel' : '➕ Add Cloud Account'}
        </button>
      </div>

      {showAddForm && (
        <div className="add-account-form">
          <h3>Add New Cloud Account</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Account Name *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Production AWS Account"
                required
              />
            </div>

            <div className="form-group">
              <label>Cloud Provider *</label>
              <select
                value={formData.provider}
                onChange={(e) => handleProviderChange(e.target.value)}
              >
                <option value="aws">Amazon Web Services (AWS)</option>
                <option value="gcp">Google Cloud Platform (GCP)</option>
                <option value="azure">Microsoft Azure</option>
              </select>
            </div>

            {renderCredentialFields()}

            <div className="form-actions">
              <button type="submit" className="btn-primary" disabled={loading}>
                {loading ? '⏳ Adding...' : '✅ Add Account'}
              </button>
              <button 
                type="button" 
                className="btn-secondary"
                onClick={() => setShowAddForm(false)}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="accounts-list">
        <h3>Configured Cloud Accounts ({accounts.length})</h3>
        
        {accounts.length === 0 ? (
          <div className="empty-state">
            <p>🔒 No cloud accounts configured yet.</p>
            <p>Add your first cloud account to start provisioning clusters.</p>
          </div>
        ) : (
          <div className="accounts-grid">
            {accounts.map((account) => (
              <div key={account.id} className="account-card">
                <div className="account-header">
                  <h4>{account.name}</h4>
                  <span className={`provider-badge ${account.provider}`}>
                    {account.provider.toUpperCase()}
                  </span>
                </div>
                
                <div className="account-details">
                  <p><strong>Region:</strong> {account.credentials?.region || 'Not specified'}</p>
                  <p><strong>Status:</strong> 
                    <span className={`status ${account.status || 'active'}`}>
                      {account.status === 'active' ? '✅ Active' : '⚠️ Inactive'}
                    </span>
                  </p>
                  <p><strong>Created:</strong> {new Date(account.created_at).toLocaleDateString()}</p>
                </div>

                <div className="account-actions">
                  <button 
                    className="btn-danger"
                    onClick={() => deleteAccount(account.id)}
                  >
                    🗑️ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Main App Component
const App = () => {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [user, setUser] = useState(null);
  const [organization, setOrganization] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing authentication
    const token = localStorage.getItem('jwt_token');
    const userData = localStorage.getItem('user_data');
    const orgData = localStorage.getItem('organization_data');

    if (token && userData && orgData) {
      setUser(JSON.parse(userData));
      setOrganization(JSON.parse(orgData));
    }
    setLoading(false);
  }, []);

  const handleLogin = (loginData) => {
    setUser(loginData.user);
    setOrganization(loginData.organization);
  };

  const handleLogout = () => {
    localStorage.removeItem('jwt_token');
    localStorage.removeItem('user_data');
    localStorage.removeItem('organization_data');
    setUser(null);
    setOrganization(null);
    setCurrentPage('dashboard');
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard organization={organization} />;
      case 'create':
        return <ClusterCreation />;
      case 'manage':
        return <ClusterManagement />;
      case 'monitoring':
        return (
          <div className="page-placeholder">
            <h2>📈 Real-Time Monitoring</h2>
            <p>Advanced monitoring dashboard coming soon...</p>
          </div>
        );
      case 'accounts':
        return <CloudAccountManager />;
      default:
        return <Dashboard organization={organization} />;
    }
  };

  if (loading) {
    return <div className="loading">🔄 Loading...</div>;
  }

  if (!user) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="app">
      <Header user={user} organization={organization} onLogout={handleLogout} />
      
      <div className="app-content">
        <nav className="sidebar">
          <button 
            className={currentPage === 'dashboard' ? 'active' : ''}
            onClick={() => setCurrentPage('dashboard')}
          >
            📊 Dashboard
          </button>
          <button 
            className={currentPage === 'create' ? 'active' : ''}
            onClick={() => setCurrentPage('create')}
          >
            ➕ Create Cluster
          </button>
          <button 
            className={currentPage === 'manage' ? 'active' : ''}
            onClick={() => setCurrentPage('manage')}
          >
            ⚙️ Manage Clusters
          </button>
          <button 
            className={currentPage === 'monitoring' ? 'active' : ''}
            onClick={() => setCurrentPage('monitoring')}
          >
            📈 Monitoring
          </button>
          <button 
            className={currentPage === 'accounts' ? 'active' : ''}
            onClick={() => setCurrentPage('accounts')}
          >
            ☁️ Cloud Accounts
          </button>
        </nav>

        <main className="main-content">
          {renderCurrentPage()}
        </main>
      </div>
    </div>
  );
};

export default App;

